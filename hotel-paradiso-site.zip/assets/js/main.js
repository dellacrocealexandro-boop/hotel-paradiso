// JS opzionale per interazioni future
