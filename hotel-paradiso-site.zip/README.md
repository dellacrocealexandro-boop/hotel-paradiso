# Hotel Paradiso Portovenere — Sito statico
- Carica l'intera cartella su GitHub (web → Add file → Upload files) e poi **Connect Git Repository** su Vercel.
- Per collegare il booking engine: apri `index.html` e `rooms.html`, sostituisci `href="#"` del pulsante **Prenota** con l’URL ufficiale.
- Per immagini reali: sostituisci i file in `assets/img/` mantenendo gli stessi nomi, oppure aggiorna i percorsi nel codice.
- Dominio: su Vercel → **Domains** → aggiungi il tuo dominio e imposta il redirect da `www.`.
